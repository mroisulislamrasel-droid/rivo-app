RIVO PROFESSIONAL VERSION

1. Open Supabase -> SQL Editor.
2. Paste everything from supabase.sql and press Run.
3. Open index.html and replace:
   YOUR_SUPABASE_URL
   YOUR_SUPABASE_ANON_KEY
   with your Supabase Project URL and the public anon key.
4. Upload index.html to your GitHub repository and replace the old index.html.
5. GitHub Pages will deploy it from main/root.
6. Create an account in Rivo, then upload a video.

Important:
- Use the public "anon" key in the browser. Never put a Supabase service_role key in index.html.
- This is a real Supabase-backed web app, not a hard-coded demo feed.
- The app expects the "videos" storage bucket created by supabase.sql.
- For a true production launch, add moderation/admin tools, rate limiting, email verification policy, reporting, content scanning, CDN/video transcoding, and stronger abuse protection.
