-- RIVO PROFESSIONAL DATABASE
-- Run this ONCE in Supabase SQL Editor.

create extension if not exists "uuid-ossp";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  full_name text default '',
  avatar_url text default '',
  bio text default '',
  created_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_url text not null,
  thumbnail_url text default '',
  caption text default '',
  hashtags text default '',
  views bigint not null default 0,
  status text not null default 'published' check (status in ('draft','published','blocked')),
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,video_id)
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(follower_id,following_id),
  check(follower_id <> following_id)
);

create table if not exists public.comments (
  id uuid primary key default uuid_generate_v4(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);

-- Helpful indexes
create index if not exists videos_created_at_idx on public.videos(created_at desc);
create index if not exists videos_user_id_idx on public.videos(user_id);
create index if not exists comments_video_id_idx on public.comments(video_id);
create index if not exists follows_following_id_idx on public.follows(following_id);

-- Auto-create a profile after signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  base_name text;
begin
  base_name := lower(regexp_replace(coalesce(new.raw_user_meta_data->>'username', split_part(new.email,'@',1)), '[^a-zA-Z0-9_]', '', 'g'));
  if base_name = '' then base_name := 'rivo_user'; end if;
  if exists(select 1 from public.profiles where username=base_name) then
    base_name := base_name || '_' || substr(replace(new.id::text,'-',''),1,6);
  end if;
  insert into public.profiles(id,username,full_name)
  values(new.id,base_name,coalesce(new.raw_user_meta_data->>'full_name',base_name))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Atomic view counter.
create or replace function public.increment_video_view(p_video_id uuid)
returns void
language sql
security definer
set search_path = public
as $$
  update public.videos set views = views + 1 where id = p_video_id and status = 'published';
$$;

grant execute on function public.increment_video_view(uuid) to anon, authenticated;

-- RLS
alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.likes enable row level security;
alter table public.follows enable row level security;
alter table public.comments enable row level security;

drop policy if exists "profiles_public_read" on public.profiles;
create policy "profiles_public_read" on public.profiles for select using (true);

drop policy if exists "profiles_own_insert" on public.profiles;
create policy "profiles_own_insert" on public.profiles for insert with check (auth.uid()=id);

drop policy if exists "profiles_own_update" on public.profiles;
create policy "profiles_own_update" on public.profiles for update using (auth.uid()=id) with check (auth.uid()=id);

drop policy if exists "videos_public_read" on public.videos;
create policy "videos_public_read" on public.videos for select using (status='published' or auth.uid()=user_id);

drop policy if exists "videos_own_insert" on public.videos;
create policy "videos_own_insert" on public.videos for insert with check (auth.uid()=user_id);

drop policy if exists "videos_own_update" on public.videos;
create policy "videos_own_update" on public.videos for update using (auth.uid()=user_id) with check (auth.uid()=user_id);

drop policy if exists "videos_own_delete" on public.videos;
create policy "videos_own_delete" on public.videos for delete using (auth.uid()=user_id);

drop policy if exists "likes_read" on public.likes;
create policy "likes_read" on public.likes for select using (true);

drop policy if exists "likes_own_insert" on public.likes;
create policy "likes_own_insert" on public.likes for insert with check (auth.uid()=user_id);

drop policy if exists "likes_own_delete" on public.likes;
create policy "likes_own_delete" on public.likes for delete using (auth.uid()=user_id);

drop policy if exists "follows_read" on public.follows;
create policy "follows_read" on public.follows for select using (true);

drop policy if exists "follows_own_insert" on public.follows;
create policy "follows_own_insert" on public.follows for insert with check (auth.uid()=follower_id);

drop policy if exists "follows_own_delete" on public.follows;
create policy "follows_own_delete" on public.follows for delete using (auth.uid()=follower_id);

drop policy if exists "comments_read" on public.comments;
create policy "comments_read" on public.comments for select using (true);

drop policy if exists "comments_own_insert" on public.comments;
create policy "comments_own_insert" on public.comments for insert with check (auth.uid()=user_id);

drop policy if exists "comments_own_delete" on public.comments;
create policy "comments_own_delete" on public.comments for delete using (auth.uid()=user_id);

-- Storage bucket for videos.
insert into storage.buckets (id,name,public)
values ('videos','videos',true)
on conflict (id) do update set public=true;

drop policy if exists "video_storage_public_read" on storage.objects;
create policy "video_storage_public_read"
on storage.objects for select
using (bucket_id='videos');

drop policy if exists "video_storage_auth_insert" on storage.objects;
create policy "video_storage_auth_insert"
on storage.objects for insert to authenticated
with check (
  bucket_id='videos'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "video_storage_own_update" on storage.objects;
create policy "video_storage_own_update"
on storage.objects for update to authenticated
using (
  bucket_id='videos'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "video_storage_own_delete" on storage.objects;
create policy "video_storage_own_delete"
on storage.objects for delete to authenticated
using (
  bucket_id='videos'
  and (storage.foldername(name))[1] = auth.uid()::text
);
